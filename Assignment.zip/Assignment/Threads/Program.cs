﻿using System;
using System.Net.Mime;
using System.Threading;

namespace Threads
{
    class Program
    {
        static void Main(string[] args)
        {
            //ThreadsImpByTimers threads = new ThreadsImpByTimers();
            //Console.ReadKey();
            //ThreadsImpByTimers.Terminate();
            //ThreadsImpByTimers.Sleep(1000);

            Threads threads2 = new Threads();
            
            Console.ReadKey();
            threads2.TerminateThreads();
            Thread.Sleep(1000);
        }
    }
}

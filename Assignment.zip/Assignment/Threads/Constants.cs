﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Threads
{
    class Constants
    {
        internal const int THREAD1_INTERVAL = 100;
        internal const int THREAD2_INTERVAL = 200;
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace Threads
{
    class Threads
    {
        // New coding conventions from 2020 recommend using no prefixes for class member fields.
        private readonly object lockObj = new object();
        private bool isRunning;
        private Thread firstThread;
        private Thread secondThread;

        internal Threads()
        {
            InitFirstThread();
            InitSecondThread();
        }

        private void InitFirstThread()
        {
            firstThread = new Thread(new ThreadStart(Thread1_WriteToConsole))
            {
                Name = "Thread1"
            };
            isRunning = true;
            firstThread.Start();
        }

        private void InitSecondThread()
        {
            secondThread = new Thread(new ThreadStart(Thread2_WriteToConsole))
            {
                Name = "Thread2"
            };
            isRunning = true;
            secondThread.Start();
        }

        private void Thread1_WriteToConsole()
        {
            while (isRunning)
            {
                lock (lockObj)
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("Thread1");
                }

                Thread.Sleep(Constants.THREAD1_INTERVAL);
            }
        }

        private void Thread2_WriteToConsole()
        {
            while (isRunning)
            {
                lock (lockObj)
                {
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.WriteLine("Thread2");
                }

                Thread.Sleep(Constants.THREAD2_INTERVAL);
            }
        }

        internal void TerminateThreads()
        {
            isRunning = false;
        }
    }
}

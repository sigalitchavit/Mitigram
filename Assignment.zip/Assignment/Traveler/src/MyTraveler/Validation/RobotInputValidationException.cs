﻿/* Author: Sigalit Chavit */
using System;

namespace RobotRunner.Validation
{
    // An example to an application0specific exception. In "real life" further handling should be added, 
    // e.g. a logging mechanism.
    public class RobotInputValidationException: Exception
    {
        public RobotInputValidationException()
        {
        }

        public RobotInputValidationException(string message)
            : base(message)
        {
            
        }

        public RobotInputValidationException(string message, Exception inner)
            : base(message, inner)
        {
            
        }
    }
}

﻿using System;
/* Author: Sigalit Chavit */
using System.Collections.Generic;
using RobotRunner.Model;
using RobotRunner.Services;

namespace RobotRunner.Program
{
    // The main class for running the robot using the input data.
    public static class RobotRunner
    {
        public static IList<Position> Run(string input)
        {
            var results = new List<Position>();

            var trips = ParserService.ExtractTrips(input);

            try
            {
                foreach (var trip in trips)
                {
                    var position = PathCalcService.CalcTrip(trip);
                    results.Add(position);
                }
            }

            catch (Exception e)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"Error: {e.Message}");
                if (e.InnerException != null)
                {
                    Console.WriteLine($"Error: {e.InnerException.Message}");
                }
            }

            return results;
        }
    }
}

﻿/* Author: Sigalit Chavit */

namespace RobotRunner.Program
{
    // I assumed that you wanted an exe...
    class Program
    {
        static void Main(string[] args)
        {
            // Having the ability to run it outside of the tests environment.
            // var input = "POS=0,0,E\r\nFFFRFFF";
            // var result = MyTravelParser.Run(input);
            // Console...
        }
    }
}

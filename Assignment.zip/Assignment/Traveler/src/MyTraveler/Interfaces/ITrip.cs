﻿/* Author: Sigalit Chavit */
using RobotRunner.Model;

namespace RobotRunner.Interfaces
{
    interface ITrip
    {
        public Position StartPosition { get; }
        public char[] Commands { get; }
    }
}

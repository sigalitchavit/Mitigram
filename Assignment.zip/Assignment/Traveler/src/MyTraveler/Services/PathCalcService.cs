﻿/* Author: Sigalit Chavit */
using RobotRunner.Model;
using RobotRunner.Validation;

namespace RobotRunner.Services
{
    // This class is responsible for routing the robot according to the   
    // input location and commands, to the destination of the path.
    class PathCalcService
    {
        internal static Position CalcTrip(Trip trip)
        {
            Position position = trip.StartPosition;

            foreach (var cmd in trip.Commands)
            {
                position = CalcCommand(position, cmd);
            }

            return position;
        }

        private static Position CalcCommand(Position currentPos, char operation)
        {
            Position retPosition = currentPos;

            switch (operation)
            {
                case 'F':
                    switch (currentPos.Direction)
                    {
                        case 'N':
                            retPosition.Y = currentPos.Y - 1; 
                            break;
                        case 'S':
                            retPosition.Y = currentPos.Y + 1; 
                            break;
                        case 'E':
                            retPosition.X = currentPos.X + 1; 
                            break;
                        case 'W':
                            retPosition.X = currentPos.X - 1; 
                            break;
                        default:
                            throw new RobotInputValidationException($"Invalid direction: {currentPos.Direction}");
                    }

                    break;
                case 'B':
                    switch (currentPos.Direction)
                    {
                        case 'N':
                            retPosition.Y = currentPos.Y + 1; 
                            break;
                        case 'S':
                            retPosition.Y = currentPos.Y - 1; 
                            break;
                        case 'E':
                            retPosition.X = currentPos.X - 1; 
                            break;
                        case 'W':
                            retPosition.X = currentPos.X + 1;
                            break;
                        default:
                            throw new RobotInputValidationException($"Invalid direction: {currentPos.Direction}");
                    }

                    break;

                case 'L':
                case 'R':
                    retPosition.Direction = Rotate(currentPos.Direction, operation);

                    break;

                default:
                    throw new RobotInputValidationException($"Invalid input operation: {operation}");
            }

            return retPosition;
        }


        private static char Rotate(char direction, char operation)
        {
            char retVal;

            switch (direction)
            {
                case 'N':
                {
                    switch (operation)
                    {
                        case 'F': 
                            retVal = 'N'; 
                            break;
                        case 'B': 
                            retVal = 'N'; 
                            break;
                        case 'L': 
                            retVal = 'W'; 
                            break;
                        case 'R': 
                            retVal = 'E'; 
                            break;
                        default:
                            throw new RobotInputValidationException($"Invalid input operation: {operation}");
                    }

                    break;
                }

                case 'S':
                {
                    switch (operation)
                    {
                        case 'F': 
                            retVal = 'S';
                            break;
                        case 'B': 
                            retVal = 'S';
                            break;
                        case 'L': 
                            retVal = 'E';
                            break;
                        case 'R': 
                            retVal = 'W';
                            break;
                        default:
                            throw new RobotInputValidationException($"Invalid input operation: {operation}");
                    }

                    break;
                }

                case 'E':
                {
                    switch (operation)
                    {
                        case 'F': 
                            retVal = 'E';
                            break;
                        case 'B': 
                            retVal = 'E';
                            break;
                        case 'L': 
                            retVal = 'N';
                            break;
                        case 'R': 
                            retVal = 'S';
                            break;
                        default:
                            throw new RobotInputValidationException($"Invalid input operation: {operation}");
                        }

                    break;
                }

                case 'W':
                {
                    switch (operation)
                    {
                        case 'F': 
                            retVal = 'W';
                            break;
                        case 'B': 
                                retVal = 'W';
                                break;
                        case 'L': 
                                retVal = 'S';
                                break;
                        case 'R': 
                                retVal = 'N';
                                break;
                        default:
                            throw new RobotInputValidationException($"Invalid input operation: {operation}");
                        }

                    break;
                }

                default:
                    throw new RobotInputValidationException($"Invalid direction: {direction}");
            }

            return retVal;
        }
    }
}

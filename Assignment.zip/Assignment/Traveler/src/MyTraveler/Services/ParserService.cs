﻿/* Author: Sigalit Chavit */
using System;
using System.Collections.Generic;
using System.Linq;
using RobotRunner.Model;
using RobotRunner.Validation;

namespace RobotRunner.Services
{
    // This class is responsible for parsing the input string and creating a comprehensive collection 
    // of input data out of it.
    class ParserService
    {
        private static readonly char[] DirectionChars = { 'N', 'S', 'E', 'W' };

        internal static List<Trip> ExtractTrips(string input)
        {
            var trips = new List<Trip>();
            var inputTrips = input.Split("POS=");

            foreach (var inputTrip in inputTrips)
            {
                // The Spilt method deletes the search text and leaves the first entry empty
                if (!string.IsNullOrEmpty(inputTrip))
                {
                    if (!inputTrip.StartsWith("//"))
                    {
                        // Return the "POS=" prefix which was removed by the Split() method.
                        var trip = $"POS={inputTrip}";
                        var position = ParsePosition(trip);
                        var commands = ParseCommands(trip);

                        trips.Add(new Trip(position, commands));
                    }
                }
            }

            return trips;
        }

        /// <summary>
        /// Returns the initial position part after validating it.
        /// </summary>
        /// <param name="input">the complete input</param>
        /// <returns>the position part of the input string.</returns>
        private static Position ParsePosition(string input)
        {
            var split = input.Split('\r', '\n');
            var posLine = split[0];
            if (!posLine.StartsWith("POS=")) 
            {
                throw new RobotInputValidationException("Missing position!");
            }

            var retPosition = new Position();

            // Split by '=':
            var splitByEqual = posLine.Split('=');

            if (splitByEqual.Length != 2)
                throw new RobotInputValidationException("Invalid position format!");

            var positions = splitByEqual[1];
            var positionsSplit = positions.Split(',');
            if (positionsSplit.Length != 3)
                throw new RobotInputValidationException("Invalid position format!");

            // verify that the 1st parameter is of type int:
            if (!Int32.TryParse(positionsSplit[0], out var x))
                throw new RobotInputValidationException("Invalid position format!");
            retPosition.X = x;

            // verify that the 2nd parameter is of type int:
            if (!Int32.TryParse(positionsSplit[1], out var y))
                throw new RobotInputValidationException("Invalid position format!");
            retPosition.Y = y;

            // verify that the 3rd parameter is of type char:
            if (!Char.TryParse(positionsSplit[2], out var direction))
                throw new RobotInputValidationException("Invalid position format!");

            // Verify that the 3rd parameter is one of the first 4 direction letters:
            if (!DirectionChars.Contains(direction))
                throw new RobotInputValidationException("Invalid position format!");

            // Assign direction to the positions return value:
            retPosition.Direction = direction;

            return retPosition;
        }

        private static char[] ParseCommands(string input)
        {
            string commands = string.Empty;

            if (input.Contains("\r") || input.Contains("\n"))  // An empty command is allowed.
            {
                // Find the index of the first '\n' separator to remove the position part from the string:
                int splitIndex = input.First(ch => ch.Equals('\n'));

                // Take the rest of the input string after the first '\n':
                commands = input.Substring(splitIndex);

                // Remove all newlines:
                commands = commands.Replace("\r", string.Empty);
                commands = commands.Replace("\n", string.Empty);
            }

            return commands.ToCharArray();
        }
    }
}

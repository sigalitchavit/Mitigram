﻿/* Author: Sigalit Chavit */
/* Author: Sigalit Chavit */

namespace RobotRunner.Model
{
    // I decided to go with a struct as:
    //   1. Logically represents a single value
    //   2. It contains only primitives
    //   3. It is immutable
    //   4. It represents a small amount of bytes
    //   5. It should not be un/boxed frequently
    public struct Position
    {
        public int X { get; set; }
        public int Y { get; set; }
        public char Direction { get; set; }
    }
}

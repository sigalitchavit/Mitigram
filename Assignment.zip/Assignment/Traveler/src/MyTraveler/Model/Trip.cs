﻿/* Author: Sigalit Chavit */

using RobotRunner.Interfaces;

namespace RobotRunner.Model
{
    public class Trip: ITrip
    {
        public Position StartPosition { get; }
        public char[] Commands { get; }
        public Trip(Position position, char[] commands)
        {
            StartPosition = position;
            Commands = commands;
        }
    }
}

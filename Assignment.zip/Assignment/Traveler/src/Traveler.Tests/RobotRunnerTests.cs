using Shouldly;
using System;
using RobotRunner.Program;
using Xunit;

namespace Traveler.Tests
{
    // These tests are the same as the original tests, only with a reference to my project RobotRunner, 
    // which is an enhancement to the original TravelParser code.
    public class RobotRunnerTests
    {
        [Fact]
        public void Should_Run_Single_Scenario_With_Expected_Outcome()
        {
            // Given
            var input = "POS=0,0,E\r\nFFFRFFF";

            // When
            var result = RobotRunner.Program.RobotRunner.Run(input);

            // Then
            result.Count.ShouldBe(1);

            result[0].X.ShouldBe(3);
            result[0].Y.ShouldBe(3);
            result[0].Direction.ShouldBe('S');
        }

        [Fact]
        public void Should_Run_Multiple_Scenarios_With_Expected_Outcome()
        {
            // Given
            var input = "POS=0,0,E\r\nFFFRFFF\r\nPOS=6,4,W\r\nBLFLFFFFFRFRFLFL\r\nBLBLBRBL\r\nPOS=1,1,N";

            // When
            var result = RobotRunner.Program.RobotRunner.Run(input);

            // Then
            result.Count.ShouldBe(3);

            result[0].X.ShouldBe(3);
            result[0].Y.ShouldBe(3);
            result[0].Direction.ShouldBe('S');

            result[1].X.ShouldBe(11);
            result[1].Y.ShouldBe(9);
            result[1].Direction.ShouldBe('W');

            result[2].X.ShouldBe(1);
            result[2].Y.ShouldBe(1);
            result[2].Direction.ShouldBe('N');
        }

        [Fact]
        public void Should_Not_Require_Operations()
        {
            // Given
            var input = "POS=1,1,N";

            // When
            var result = RobotRunner.Program.RobotRunner.Run(input);

            // Then
            result.Count.ShouldBe(1);

            result[0].X.ShouldBe(1);
            result[0].Y.ShouldBe(1);
            result[0].Direction.ShouldBe('N');
        }

        [Fact]
        public void Should_Support_Single_Line_Feed_As_Separator()
        {
            // Given
            var input = "POS=0,0,E\nFFFRFFF";

            // When
            var result = RobotRunner.Program.RobotRunner.Run(input);

            // Then
            result.Count.ShouldBe(1);

            result[0].X.ShouldBe(3);
            result[0].Y.ShouldBe(3);
            result[0].Direction.ShouldBe('S');
        }

        [Fact]
        public void Should_Support_Comments()
        {
            // Given
            var input = "//Hello World\r\nPOS=0,0,E\r\nFFFRFFF";

            // When
            var result = RobotRunner.Program.RobotRunner.Run(input);

            // Then
            result.Count.ShouldBe(1);

            result[0].X.ShouldBe(3);
            result[0].Y.ShouldBe(3);
            result[0].Direction.ShouldBe('S');
        }
    }
}
